Editorial Manager LaTeX source archive

Main document: supplement.tex
Keep every file in this single directory. Filenames are unique.
Scientific text, bibliography entries and figure bytes are unchanged;
only input, bibliography and graphics dependency paths were flattened.

Compile with a XeLaTeX-compatible distribution and BibTeX, or Tectonic
with a complete LaTeX bundle. The bibliography style is plainnat.
Run LaTeX and BibTeX as needed to resolve citations and cross-references.
No project-root search path or external image download is required.
